# Ultivora StressLab + ShieldProbe

A self-hosted infrastructure diagnostics and authorized benchmarking MVP.

**Included and functional**
- Web dashboard and FastAPI backend
- Admin-token protected API
- Domain registration and DNS TXT ownership verification
- Safe single-target diagnostics for verified domains
- DNS A/AAAA/NS/TXT inspection
- TLS certificate expiry and issuer checks
- HTTP status, response timing and security-header checks
- Cloudflare presence/configuration hints
- JSON diagnostic reports
- Audit events
- Docker Compose deployment

**Provider integration status**
- Cloudflare: optional read-only API integration for listing zones with an API token.
- OVHcloud: provider integration configuration foundation and documented read-only integration path.
- Oracle Cloud: provider integration configuration foundation and documented read-only integration path.

Provider credentials are not required for the core diagnostics. No credentials are bundled.

## Important scope
This is a defensive diagnostics product. It does not contain provider bypasses, DDoS functionality,
IP spoofing, reflection/amplification, botnet control, arbitrary port scanning, or resource-exhaustion
features. It only diagnoses a domain after DNS TXT ownership verification. Tests are single-request
checks with timeouts, not traffic floods.

## Quick start (Docker)
1. Copy `.env.example` to `.env`.
2. Set `ADMIN_TOKEN` to a long random secret.
3. Run `docker compose up --build -d`.
4. Open `http://YOUR_SERVER_IP:8080`.
5. Enter the admin token in the dashboard.

For production, put the app behind HTTPS using Nginx/Caddy, restrict inbound access,
use persistent backups, and rotate the admin token.

## Local development
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Set ADMIN_TOKEN in .env
uvicorn app.main:app --host 127.0.0.1 --port 8080
```

## Cloudflare
Create a Cloudflare API token with the minimum required read-only Zone:Read permission.
Set `CLOUDFLARE_API_TOKEN` in `.env`. The dashboard/API can then list zones visible to that token.
Never use a Global API Key.

## OVHcloud and Oracle Cloud
The integration page documents the credential fields and safe read-only integration approach.
The current build does not make privileged changes to provider accounts. Add provider-specific
read-only API clients only after configuring least-privilege application credentials.

## API
All `/api/*` endpoints require:
`Authorization: Bearer <ADMIN_TOKEN>`

- `GET /api/health`
- `GET /api/targets`
- `POST /api/targets`
- `POST /api/targets/{id}/verify`
- `POST /api/targets/{id}/diagnose`
- `GET /api/reports`
- `GET /api/reports/{id}`
- `GET /api/integrations`
- `GET /api/integrations/cloudflare/zones`

Target creation body:
```json
{"domain":"example.com"}
```

Diagnostics are available only after TXT verification. Publish the generated token as:
`_stresslab-verify.example.com TXT "stresslab-verification=<token>"`

## Data
SQLite database is stored at `/data/stresslab.db` in Docker. Back it up regularly.
