# Basic validation tests; run with: python -m unittest discover -s tests
import unittest
from fastapi import HTTPException
from app.main import normalize_domain

class DomainValidationTests(unittest.TestCase):
    def test_valid_domain(self):
        self.assertEqual(normalize_domain("Example.COM"), "example.com")
    def test_reject_ip(self):
        with self.assertRaises(HTTPException):
            normalize_domain("8.8.8.8")
    def test_reject_localhost(self):
        with self.assertRaises(HTTPException):
            normalize_domain("localhost")
    def test_reject_url_path(self):
        with self.assertRaises(HTTPException):
            normalize_domain("https://example.com/path")

if __name__ == "__main__":
    unittest.main()
