# Operations and production hardening

- Terminate TLS at a maintained reverse proxy.
- Keep port 8080 bound to loopback (Compose default).
- Use a random ADMIN_TOKEN with at least 32 characters.
- Restrict dashboard access with VPN/IP allowlisting where possible.
- Back up `/data/stresslab.db` and test restoration.
- Rotate provider tokens and use least privilege.
- Monitor disk space, application logs and backup age.
- Keep Python dependencies updated and scan container images.
- Add SSO, per-user roles and secret-manager integration before offering public multi-tenant SaaS.
- Add rate limits and CSRF protections before exposing state-changing browser endpoints publicly.
