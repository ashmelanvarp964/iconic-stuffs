# Provider integrations

## Cloudflare (partially implemented)
The application supports an optional read-only Cloudflare API token to list zones.
Use a token scoped to the minimum required zone read permission. Do not use the
Global API Key. The integration deliberately does not change WAF, rate-limit,
bot-management, DNS proxy or DDoS settings and does not bypass protections.

## OVHcloud (foundation)
The environment file reserves fields for OVH application credentials. Before enabling
an API client, configure an OVH application with read-only permissions for only the
required service/instance metadata. Store credentials in a secret manager, sign requests
using the official OVH API authentication scheme, and log all access. No automated
network-protection changes or bypass functionality is provided.

## Oracle Cloud Infrastructure (foundation)
Use an OCI user/API key or instance principal with narrowly scoped read-only IAM
policies. Prefer instance-principal authentication on OCI compute instances. A future
adapter can read compute instance and VNIC metadata and compare security-list/NSG
configuration to a policy baseline. Do not grant broad tenancy administrator access.

## Diagnostic posture
Provider identification based on DNS nameservers or response headers is heuristic.
The provider API is the authoritative source for account configuration. Never infer
that a protection is enabled or disabled solely from a header.
