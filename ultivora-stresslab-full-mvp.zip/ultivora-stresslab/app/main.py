import os, re, json, time, uuid, socket, ssl, sqlite3, ipaddress
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse
import requests
import dns.resolver
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

load_dotenv()
APP_DIR = Path(__file__).parent
DB_PATH = os.getenv("DATABASE_PATH", "./stresslab.db")
ADMIN_TOKEN = os.getenv("ADMIN_TOKEN", "")
CLOUDFLARE_API_TOKEN = os.getenv("CLOUDFLARE_API_TOKEN", "")

app = FastAPI(title="Ultivora StressLab", version="1.0.0",
              description="Authorized infrastructure diagnostics and ShieldProbe.")
app.mount("/static", StaticFiles(directory=str(APP_DIR / "static")), name="static")

def now():
    return datetime.now(timezone.utc).isoformat()

def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS targets(
            id TEXT PRIMARY KEY, domain TEXT UNIQUE NOT NULL, token TEXT NOT NULL,
            verified INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, verified_at TEXT)""")
        con.execute("""CREATE TABLE IF NOT EXISTS reports(
            id TEXT PRIMARY KEY, target_id TEXT NOT NULL, domain TEXT NOT NULL,
            created_at TEXT NOT NULL, result_json TEXT NOT NULL)""")
        con.execute("""CREATE TABLE IF NOT EXISTS audit(
            id TEXT PRIMARY KEY, event TEXT NOT NULL, detail TEXT NOT NULL, created_at TEXT NOT NULL)""")

init_db()

def audit(event, detail):
    with db() as con:
        con.execute("INSERT INTO audit VALUES(?,?,?,?)",
                    (str(uuid.uuid4()), event, detail[:1000], now()))

def auth(authorization: str = Header(default="")):
    if not ADMIN_TOKEN or len(ADMIN_TOKEN) < 32:
        raise HTTPException(503, "Set ADMIN_TOKEN to a random secret of at least 32 characters.")
    if authorization != f"Bearer {ADMIN_TOKEN}":
        raise HTTPException(401, "Invalid admin token.")
    return True

class TargetIn(BaseModel):
    domain: str = Field(min_length=3, max_length=253)

def normalize_domain(value):
    value = value.strip().lower().rstrip(".")
    if "://" in value:
        value = urlparse(value).hostname or ""
    if not value or len(value) > 253 or not re.fullmatch(r"(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(?:\.(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?))+", value):
        raise HTTPException(400, "Enter a valid public domain name, not a URL, IP address or local hostname.")
    try:
        ipaddress.ip_address(value)
        raise HTTPException(400, "IP addresses are not accepted. Verify a domain you control.")
    except ValueError:
        pass
    return value

def resolve_records(domain, record_type):
    try:
        answers = dns.resolver.resolve(domain, record_type, lifetime=4)
        return [str(a).strip('"') for a in answers]
    except Exception:
        return []

def verified_target(target_id):
    with db() as con:
        row = con.execute("SELECT * FROM targets WHERE id=?", (target_id,)).fetchone()
    if not row:
        raise HTTPException(404, "Target not found.")
    if not row["verified"]:
        raise HTTPException(403, "Target ownership must be verified before diagnostics.")
    return dict(row)

def public_dns_check(domain):
    results = {}
    for typ in ("A", "AAAA", "NS", "MX", "TXT"):
        results[typ] = resolve_records(domain, typ)
    # Refuse diagnostic network requests if any resolved address is non-public.
    addresses = results["A"] + results["AAAA"]
    for addr in addresses:
        try:
            ip = ipaddress.ip_address(addr)
            if not ip.is_global:
                raise HTTPException(400, "Domain resolves to a non-public address; diagnostics blocked.")
        except ValueError:
            continue
    return results

def http_check(domain):
    url = f"https://{domain}/"
    started = time.monotonic()
    try:
        # No redirect following: prevents redirect-based SSRF.
        response = requests.get(url, timeout=(4, 8), allow_redirects=False,
                                headers={"User-Agent": "Ultivora-StressLab-ShieldProbe/1.0"})
        elapsed = round((time.monotonic() - started) * 1000, 2)
        headers = {k.lower(): v for k, v in response.headers.items()}
        checks = {
            "strict_transport_security": "strict-transport-security" in headers,
            "content_security_policy": "content-security-policy" in headers,
            "x_content_type_options": "nosniff" in headers.get("x-content-type-options", "").lower(),
            "frame_protection": "x-frame-options" in headers or "frame-ancestors" in headers.get("content-security-policy", ""),
            "referrer_policy": "referrer-policy" in headers,
            "permissions_policy": "permissions-policy" in headers
        }
        return {"url": url, "status_code": response.status_code, "response_time_ms": elapsed,
                "server_header": headers.get("server", "Not disclosed"),
                "security_headers": checks, "redirect_not_followed": response.is_redirect}
    except requests.RequestException as exc:
        return {"url": url, "error": str(exc)[:250]}

def tls_check(domain):
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((domain, 443), timeout=5) as raw:
            with ctx.wrap_socket(raw, server_hostname=domain) as sock:
                cert = sock.getpeercert()
                expires = datetime.strptime(cert["notAfter"], "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
                days = (expires - datetime.now(timezone.utc)).days
                return {"valid": True, "issuer": dict(x[0] for x in cert.get("issuer", [])),
                        "expires_at": expires.isoformat(), "days_remaining": days}
    except Exception as exc:
        return {"valid": False, "error": str(exc)[:250]}

def diagnose(domain):
    dns_data = public_dns_check(domain)
    http_data = http_check(domain)
    tls_data = tls_check(domain)
    nameservers = " ".join(dns_data.get("NS", [])).lower()
    server = str(http_data.get("server_header", "")).lower()
    cloudflare_hint = "cloudflare" in nameservers or "cloudflare" in server or "cf-ray" in str(http_data)
    findings = []
    if not tls_data.get("valid"):
        findings.append({"severity": "high", "finding": "TLS validation failed", "recommendation": "Check certificate deployment, hostname coverage and origin TLS configuration."})
    elif tls_data.get("days_remaining", 999) < 21:
        findings.append({"severity": "medium", "finding": "TLS certificate expires soon", "recommendation": "Renew the certificate before expiry."})
    for name, enabled in http_data.get("security_headers", {}).items():
        if not enabled:
            findings.append({"severity": "low", "finding": f"Missing or weak HTTP security header: {name}", "recommendation": "Review whether this header is appropriate for the application and configure it at the application or reverse proxy."})
    if http_data.get("status_code", 200) >= 500:
        findings.append({"severity": "high", "finding": "Origin returned a server error", "recommendation": "Inspect application and reverse-proxy logs."})
    return {"domain": domain, "checked_at": now(), "dns": dns_data, "http": http_data,
            "tls": tls_data, "provider_hints": {"cloudflare_detected": cloudflare_hint,
            "note": "Provider detection is heuristic, not authoritative."}, "findings": findings}

@app.get("/")
def home():
    return FileResponse(APP_DIR / "static" / "index.html")

@app.get("/api/health")
def health():
    return {"status": "ok", "product": "Ultivora StressLab", "version": "1.0.0"}

@app.get("/api/targets", dependencies=[Depends(auth)])
def list_targets():
    with db() as con:
        rows = con.execute("SELECT id,domain,verified,created_at,verified_at FROM targets ORDER BY created_at DESC").fetchall()
    return [dict(r) for r in rows]

@app.post("/api/targets", dependencies=[Depends(auth)])
def create_target(body: TargetIn):
    domain = normalize_domain(body.domain)
    token = uuid.uuid4().hex + uuid.uuid4().hex[:16]
    target_id = str(uuid.uuid4())
    try:
        with db() as con:
            con.execute("INSERT INTO targets VALUES(?,?,?,?,?,?)",
                        (target_id, domain, token, 0, now(), None))
    except sqlite3.IntegrityError:
        raise HTTPException(409, "Target already exists.")
    audit("target.created", domain)
    return {"id": target_id, "domain": domain, "verified": False,
            "verification": {"record_type": "TXT", "hostname": f"_stresslab-verify.{domain}",
                             "value": f"stresslab-verification={token}"}}

@app.post("/api/targets/{target_id}/verify", dependencies=[Depends(auth)])
def verify_target(target_id: str):
    with db() as con:
        row = con.execute("SELECT * FROM targets WHERE id=?", (target_id,)).fetchone()
    if not row:
        raise HTTPException(404, "Target not found.")
    expected = f"stresslab-verification={row['token']}"
    records = resolve_records(f"_stresslab-verify.{row['domain']}", "TXT")
    if expected not in records:
        raise HTTPException(400, "Verification TXT record not found yet.")
    with db() as con:
        con.execute("UPDATE targets SET verified=1, verified_at=? WHERE id=?", (now(), target_id))
    audit("target.verified", row["domain"])
    return {"verified": True, "domain": row["domain"]}

@app.post("/api/targets/{target_id}/diagnose", dependencies=[Depends(auth)])
def run_diagnostics(target_id: str):
    target = verified_target(target_id)
    result = diagnose(target["domain"])
    report_id = str(uuid.uuid4())
    with db() as con:
        con.execute("INSERT INTO reports VALUES(?,?,?,?,?)",
                    (report_id, target_id, target["domain"], now(), json.dumps(result)))
    audit("diagnostics.completed", target["domain"])
    return {"report_id": report_id, "result": result}

@app.get("/api/reports", dependencies=[Depends(auth)])
def reports():
    with db() as con:
        rows = con.execute("SELECT id,target_id,domain,created_at FROM reports ORDER BY created_at DESC LIMIT 100").fetchall()
    return [dict(r) for r in rows]

@app.get("/api/reports/{report_id}", dependencies=[Depends(auth)])
def get_report(report_id: str):
    with db() as con:
        row = con.execute("SELECT * FROM reports WHERE id=?", (report_id,)).fetchone()
    if not row:
        raise HTTPException(404, "Report not found.")
    return {"id": row["id"], "domain": row["domain"], "created_at": row["created_at"],
            "result": json.loads(row["result_json"])}

@app.get("/api/integrations", dependencies=[Depends(auth)])
def integrations():
    return {
        "cloudflare": {"configured": bool(CLOUDFLARE_API_TOKEN), "mode": "read-only zone listing" if CLOUDFLARE_API_TOKEN else "not configured"},
        "ovhcloud": {"configured": bool(os.getenv("OVH_APPLICATION_KEY") and os.getenv("OVH_APPLICATION_SECRET") and os.getenv("OVH_CONSUMER_KEY")), "mode": "credential foundation; no provider changes"},
        "oracle_cloud": {"configured": bool(os.getenv("OCI_CONFIG_FILE")), "mode": "credential foundation; read-only client not enabled"}
    }

@app.get("/api/integrations/cloudflare/zones", dependencies=[Depends(auth)])
def cloudflare_zones():
    if not CLOUDFLARE_API_TOKEN:
        raise HTTPException(400, "Configure CLOUDFLARE_API_TOKEN.")
    try:
        r = requests.get("https://api.cloudflare.com/client/v4/zones",
                         headers={"Authorization": f"Bearer {CLOUDFLARE_API_TOKEN}"},
                         params={"per_page": 50}, timeout=10)
        r.raise_for_status()
        data = r.json()
        if not data.get("success"):
            raise HTTPException(502, "Cloudflare API returned an unsuccessful response.")
        return [{"id": z.get("id"), "name": z.get("name"), "status": z.get("status"),
                 "plan": (z.get("plan") or {}).get("name")} for z in data.get("result", [])]
    except requests.RequestException:
        raise HTTPException(502, "Unable to reach Cloudflare API.")

@app.get("/api/audit", dependencies=[Depends(auth)])
def audit_events():
    with db() as con:
        rows = con.execute("SELECT event,detail,created_at FROM audit ORDER BY created_at DESC LIMIT 100").fetchall()
    return [dict(r) for r in rows]
